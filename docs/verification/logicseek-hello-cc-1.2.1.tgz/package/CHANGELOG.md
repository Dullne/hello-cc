# Changelog

This project keeps one changelog file. Add one section per release, with the
newest version first. Do not create a new changelog file for every release.

Before publishing, run:

```bash
npm run release:check
npm run release:artifact:check
npm run release:notes
npm run release:github:dry-run
```

Pushing a `v*` tag runs the GitHub Release workflow, which creates or updates
the release description from the current changelog section. Use
`npm run release:github` with `GH_TOKEN` or `GITHUB_TOKEN` only for local
backfills.

## 1.2.1

### Summary

Complete Windows CLI environment setup, existing-state diagnostics, offline legacy migration, and automatic HTTPS. Improve Windows acceptance cleanup and expose bounded per-file CI failures.

### Highlights

- Emit PowerShell assignments by default on Windows; `env` and `join` support explicit `--shell powershell|cmd|posix` with safe literal handling and unchanged JSON output.
- Inspect existing private state without opening SQLite. Unsafe ACLs, junctions, hardlinks, unexpected entries, and incomplete inspection prevent a misleading ready result.
- Generate Codex hooks for its Windows PowerShell interpreter so the complete hook command executes correctly. Recognize installed encoded hooks in diagnostics, probe the same Codex installation HCC launches, and preserve PowerShell smart quotes literally in installation paths, without executing diagnostic input.
- Prevent Windows terminals from replacing native workers through either their peer or provider-session identity. Check conflicts before contacting the terminal host, before process creation, and again when publishing the binding so concurrent changes preserve the existing worker.
- Import offline legacy Windows state through retained native handles and private destination storage. Preserve source bytes, snapshot SQLite, reject live or uncertain writers, and resume only receipt-bound interrupted migrations.
- Use Windows extended filenames at SQLite and native security API boundaries so deep private-state paths support database connections, WAL history, migration snapshots, and permission diagnosis while retaining the original path checks.
- Start programs from long executable paths and report unsupported working directories before creating a process. Windows managed process, service, and terminal launches require a working-directory path of at most 258 UTF-16 code units; the error directs users to a shorter project path.
- Generate and reuse Windows self-signed HTTPS certificates with OpenSSL, private native publication, serialized certificate rotation, and real HTTPS verification. OpenSSL must be available on PATH.
- Give expensive Windows background discovery scans a completion interval and proportional cooldown so fresh identity checks leave time for Web requests.
- Close test-owned processes before removing their pinned directories. CI now records each test file and fails bounded hangs with diagnostics; artifact upload uses the current Node 24 action.
- Route the default npm development tests to the current platform: Windows uses its bounded CI contract groups and isolated installed-package lifecycle, while Linux and macOS keep the full POSIX tests.

Windows 11 x64, Node.js 24+, and local NTFS remain the accepted desktop scope. Windows 10 requires its own acceptance environment; ARM64 and network/non-NTFS storage remain unsupported. Provider authentication and model responses are separate from local runtime checks. See the current Windows follow-up validation record for exact results.

## 1.2.0

### Summary

Add native Windows support for the HCC CLI, Web file workflows, background
agents, and persistent managed terminals. Windows users can run HCC from
PowerShell or cmd without WSL, Git Bash, or tmux.

### Highlights

- Add a verified Windows x64 native component for private state, handle-relative
  project files, SQLite/WAL lifetime, process identity, Job Object ownership,
  ConPTY terminals, and safe atomic publication.
- Add a per-user terminal host that keeps owned terminals alive across Web
  restarts and enforces authenticated reconnects, bounded output, generations,
  and controller epochs.
- Add Windows hooks, provider shims, literal executable/argument resolution,
  environment diagnostics, and public CLI task/message/lock workflows for
  Unicode and space-containing paths.
- Add Windows database migration backups with native identity receipts,
  overlapping write/path guards, ACL checks, and confirmed directory flushes.
- Preserve existing POSIX backends and reject unsupported legacy state imports,
  ARM64, UNC/network filesystems, non-NTFS paths, and automatic Windows
  self-signed TLS with explicit diagnostics.

### Validation

The 1.2.0 release passed 210 Windows tests with zero failures or skips on
Windows 11 x64, local NTFS, and Node.js 24.22.3. Linux passed 2,127 unit tests
with 182 explicit platform skips and zero failures, followed by all 13 stages
of the integration regression. The final package was independently installed
and exercised through task/message/lock operations, Web restart terminal
reconnect, controlled input, terminal cleanup, and native service lifecycle.
Windows 10, macOS runtime behavior, hosted CI, and real provider account/model
workflows require separate acceptance.

## 1.1.6

### Summary

Add guarded Codex host extension callbacks, explicit retained-history migration,
and measurable long-running installed acceptance. Desktop bridge documentation
now installs from the stable channel and records the observed Claude App limit.

### Highlights

- Opt-in dynamic host tools on owned Native/Web App Servers preserve executor,
  thread, turn, call identity and per-thread read-only policy. Bound callbacks,
  cancel late results and deduplicate calls without replay after failures.
- External-token refresh is an in-process callback for existing auth hosts.
  Account mismatches and expired results fail closed; credentials and raw
  callback errors remain outside HCC state and approval flows. No login UI or
  global authentication change is introduced.
- Add offline `native history` and `native recover`: create a new session with a
  durable context-only history link, retaining old identity, sandbox and unresolved
  deliveries. Missing historical directory evidence is never fabricated.
- Installed acceptance can space bounded model work across up to 24 real hours,
  with owned recovery, a final live probe, atomic progress receipts, cancellation
  cleanup and latency/throughput measurements at the tested three-worker load.

### Validation

Protocol, ownership, recovery and CLI tests cover cancellation, duplicate calls,
secret-free refresh errors, account changes, per-thread sandbox policy and
elapsed-time enforcement. Installed-model and frozen-package receipts are
recorded separately. Claude Desktop acceptance is blocked on this device by
the App's region-unavailable page. A configured soak duration is not evidence
of a completed 24-hour run; stakeholder production acceptance remains separate.

## 1.1.5

### Summary

Require a verified immutable package before npm publication or GitHub Release
creation so a missing release manifest fails before publication.

### Highlights

- Check the versioned frozen manifest, archive digest, packaged files and modes
  before publishing. Reject a requested version that differs from the package.
- Include the frozen npm archive and file manifest used by release-mode
  DeepSeek Harness acceptance; preserve all previously published tags and files.
- Keep the 1.1.4 runtime behavior, including opted-in App inbox listener recovery.

### Validation

Release preflight tests cover a matching immutable package, missing manifests,
source drift and version mismatches. DeepSeek Harness 0.2.0-rc.2 and 0.2.1-rc.3
are checked on Linux and macOS alongside repository, Web and native workflows.

## 1.1.4

### Summary

Restore explicitly enabled Codex App inbox listeners when their project HCC
MCP reconnects, without manually supplying the new App server PID or queue home.

### Highlights

- Add per-thread `app codex auto-enable` and `auto-disable`, with recovery state
  in `dispatch-status`. Discover the current original App through process
  ancestry and its open queue file; store no session capability or mail body.
- Revalidate the project owner, App installation, queue home, executable version
  and fresh process identities on MCP startup. Preserve live manual listeners
  and refuse unreviewed CLI versions or a different App installation.
- Close managed listeners with MCP transport shutdown. Keep durable uncertain
  submissions across reconnects without replay, implicit ACK or thread restore.

### Validation

Lifecycle tests cover MCP reconnection, per-thread opt-in and disable, ownership
revocation, manual lease conflicts, exact runtime discovery and no replay after
an ambiguous queue outcome. Whole-App restart and cross-device acceptance remain
separate from these tests and from original-App MCP reconnect evidence.

## 1.1.3

### Summary

Forward unread HCC inbox notifications to the current original Codex App thread
through an optional dispatcher and the official CLI queue. The App keeps
ownership of model execution and must remain running with the thread loaded.

### Highlights

- Add `app codex watch` and `app codex dispatch-status`. Pin the selected project,
  cooperation owner, original App processes, executable and shared queue file.
  The first audited configuration is macOS Desktop CLI 0.164.0-alpha.11.1.
- Persist dispatch intent before external submission. Serialize delivery until
  explicit receiver ACK; retain uncertain submissions across failures and
  restarts without automatic replay or duplicate acknowledgements.
- Add exact-message `hcc_inbox` selection. Queue notifications contain message
  IDs and scoped commands; peer message bodies and session tokens stay off the
  external queue. Enqueue success does not establish original-App consumption.

### Validation

Targeted tests cover overlapping polls, explicit ACK, exact-message isolation,
live-owner conflicts, crash recovery, shutdown draining, timeout uncertainty,
CLI version rejection, shared queue identity and literal argument handling.
Original-App ordinary-idle acceptance and publication have separate receipts.

## 1.1.2

### Summary

Allow the hello-cc Cordis bundle to load on DeepSeek Harness 0.2.1-rc.3.
The previous exact runtime requirement rejected installation on that Desktop
release. Harness 0.2.0-rc.2 remains supported.

### Highlights

- Admit only the two verified Harness versions in package metadata and runtime
  checks. Reject mixed agent, agent-loop, tools and session package versions
  before registering collaboration tools.
- Record the runtime actually used by Cordis, inbox and installed-package
  acceptance. Exercise both supported versions in Linux and macOS CI.

### Validation

Version-fence tests cover both accepted releases, mixed core packages and an
unverified prerelease. Official runtime checks exercise idle inbox wakeup,
committed-context ACKs, replies, project isolation, admission rejection,
tool permissions, Agent disposal and session resume with local model fixtures.
Desktop activation and authenticated model communication have separate receipts.

## 1.1.1

### Summary

This maintenance release completes native submission recovery and shutdown
verification, improves ownership diagnostics, and tightens Web request and file
boundaries while retaining the existing workbench and provider interfaces.

### Highlights

- Keep CLI submission listings separate for each coordination database in the
  same project. Validate saved database bindings before filtering, and continue
  rejecting same-ID retries against a different database. Document offline
  receipt inspection and recovery with the original submission ID.
- Give owned stdio providers time to handle EOF and reap their ordinary child
  processes. Confirm process exit and stdio closure before reporting shutdown;
  retain incomplete-cleanup receipts and explicit retry behavior. Preserve safe
  loopback listener error codes and endpoints for ownership startup failures.
- Require any supplied Origin to match for Web writes, including Bearer-authenticated
  requests. Keep cookie writes dependent on affirmative same-origin evidence and
  preserve CLI requests without Origin. Query tokens remain restricted to login
  and browser session exchange.
- Preserve the original Web submission when the same Claude executor confirms
  its first session ID after a lost send response. Keep worker, generation,
  body and already-known session IDs fenced, and retain bounded HTTP retry
  diagnostics without storing response text or credentials.
- Refuse project file browsing, previews, status and context-file search on
  native Windows before filesystem access. Return HTTP 503 with WSL guidance
  instead of a pathname-based fallback; verify the guard on a Windows runner.
- Restore omitted regressions for provider reconnects, authoritative completion,
  duplicate reply/ACK suppression, uncertain deliveries, directory replacement
  before spawn and Claude hook root receipts. Add repeatable Claude transcript
  fork checks using the actual SDK and CLI with either local fixture responses
  or the caller's configured model route.
- Distinguish missing dead-pane PID evidence from a changed PID during tmux GC.
  Newer tmux versions can hide the PID after terminal exit; retain those sessions
  and their database bindings, and verify both supported observation modes in CI.

### Validation

Focused native, ownership and real HTTP tests cover the repaired paths. Installed
package and browser acceptance use isolated projects and provider fixtures.
Separate authenticated checks cover Codex, Claude and DSH replies, memory,
close/resume and interruption, plus scoped communication between providers.
Codex approval rejection and five deterministic official DSH approval scenarios
are checked separately. Claude model checks establish the configured route,
not access to an untested Anthropic model. These checks do not establish employee
device, 24-hour endurance, capacity or business acceptance. The release retains
its own immutable package and validation receipts without changing prior archives.

## 1.1.0

### Summary

This stable release promotes the multi-provider Web workbench, native Agent
coordination and project-identity protections developed through rc.9 to the
npm `latest` channel. Its runtime code is unchanged from rc.9; the stable
version has its own immutable package, tag and release acceptance receipts.

### Highlights

- Coordinate Codex, Claude and DeepSeek Harness sessions from the Web workbench
  with project Agent defaults, structured conversations and tool/approval/user
  input views. Retain terminal and App Server modes, guarded forks, retained
  drafts, file previews, reconnect and snapshot-gap recovery.
- Bind project state, managed launches, Web/native sessions and Codex history
  to the selected directory's filesystem identity. Replacement directories
  receive separate generations. Private-state v1 migration requires independent
  root verification and an explicit offline drain; old stores remain preserved.
- Ship authenticated directory-descriptor handoff helpers for Darwin and Linux
  on arm64 and x64, with static Linux binaries, executable-mode and source-stamp
  checks. Missing trusted helpers reject guarded launches without a pathname
  fallback; operators can pause new launches with `HCC_PINNED_LAUNCH_MODE=hold`.
- Fence Native, hook and scoped MCP mutations by current ownership, process and
  runtime/state generations. Journal submissions before admission, recover
  original IDs and avoid automatically replaying uncertain provider execution.
- Add opt-in original-App cooperation adapters while retaining the App's own
  execution. Harness idle-inbox wakeup and Claude hooks/plugins are separate
  provider paths; a fully idle original Codex App is not automatically awakened.
- Keep background terminal snapshots asynchronous and bounded, and retain
  separate ACL cache entries for Number and BigInt stats. Preserve exact inode,
  change-time and ACL checks, and bounded shim-registration diagnostics.

### Validation

The unchanged rc.9 runtime passed 1,992 local unit tests with three
platform/privilege skips, all 13 regression stages and 45 browser checks per
source/temporary installation. Its master CI passed 14 jobs and its immutable
release/tag CI passed three jobs on their first attempts.

The 1.1.0 version, frozen package, installed-provider checks and final commit/tag
CI retain separate release receipts. Simulated-provider browser checks remain
separate from real model calls. CI/platform execution does not establish every
employee-device, provider, cross-device recovery or business workflow. Existing
preview archives and their evidence remain unchanged.

## 1.1.0-rc.9

### Summary

This preview binds project state, managed launches and Web/native sessions to
the selected directory's filesystem identity. Replacing a directory at the
same pathname no longer authorizes reuse of its old state or Codex history.
It continues the existing npm preview channel and adds packaged native helpers
for authenticated tmux directory-descriptor handoff.

### Highlights

- Introduce private-state v2 bindings with positive directory birth-time
  receipts and separate replacement generations. Preserve the original store;
  historical v1 upgrades require independent root verification, a matching
  inspection receipt and an explicit offline drain. Interrupted upgrades remain
  fenced until a reviewed retry completes.
- Pass an already-open directory descriptor to the authorized tmux pane through
  a native broker/client, validating kernel peer identity and the bound receipt
  before launch. Ship Darwin/Linux arm64/x64 helpers, static Linux binaries and
  build/package checks; a missing trusted helper rejects the launch without a
  pathname fallback. `HCC_PINNED_LAUNCH_MODE=hold` pauses new guarded sessions.
- Recheck selected-directory identity before CLI launches, hook registration
  and managed discovery. Persist Codex thread-to-root receipts and require an
  explicit verified thread for terminal resume/fork; pathname-only histories
  and managed `--last` launches cannot establish that binding.
- Add a durable Native owner record alongside the existing file-lock guard.
  Native, hook and scoped MCP mutations recheck runtime/state generations and
  process identity under the writer fence. Journal CLI submissions before
  admission and recover with the original ID; uncertain provider execution is
  not automatically replayed. Retain sandbox and expected-generation checks.
- Bind Web project/session keys, Codex history and file/context operations to
  the selected directory and database. Preserve active sessions' original
  bindings when a replacement is explicitly selected. Keep tmux ownership and
  cleanup conditional, reject invalid routes before state resolution, and make
  user-question answers require current control and an explicit submit action.
- Document the migration, ownership and historical-session boundaries in
  Chinese and English. Add four-platform helper build/installed-package CI and
  verify executable modes and source stamps in the frozen npm package.
- Add bounded, structured shim-registration diagnostics that distinguish
  provider entry, persisted binding/pane evidence and peer-list database
  fallback. Public diagnostics retain fixture-owned booleans and finite enums.
- Keep separate ACL cache entries for Number and BigInt filesystem stats.
  Alternating validation paths reuse unchanged results while preserving exact
  inode and change-time checks; permission and ACL changes still force a fresh
  inspection in both representations.

### Validation

The rc.9 source passed 1,992 local unit tests with three platform/privilege
skips and all 13 regression stages. The integration browser baseline passed
45 checks each for source and temporary npm installations. These checks use real
HTTP, WebSocket and SQLite with simulated providers, cover desktop and 390px
layouts, and retain separate cleanup and source-hash receipts.

Native helper formats, executable permissions, C-source stamps and packed-file
hashes are checked separately from platform execution. Final source-commit CI,
the immutable rc.9 archive and tag acceptance retain their own receipts.
These checks do not establish real-model calls, device upgrades or business
acceptance. Existing released archives and their evidence remain unchanged.

## 1.1.0-rc.8

### Summary

Background tmux display refreshes no longer block the shared HTTP runtime while
waiting for terminal snapshots. This preserves responsive Agent coordination
when a tmux display command is slow, and continues the existing preview channel.

### Highlights

- Bound asynchronous background snapshots, keep one request in flight per
  session, and preserve the previous display when capture fails or times out.
- Discard stale results after a session stops, changes panes or is rebound;
  terminal display refresh does not replace process ownership checks.
- Retain the rc.7 original-App cooperation path and add delayed-tmux regression
  coverage. A reproduced synchronous display stall motivated this repair; the
  exact server-side cause of the earlier macOS CI timeout remains unconfirmed.

## 1.1.0-rc.7

### Summary

Codex App sessions can now exchange HCC messages with other Agents through
their own terminal tools and an opt-in MCP plugin. The original App retains
session execution; this adapter does not start or resume an app-server thread.
This release continues the existing preview channel.

### Highlights

- Scope cooperation to an explicitly selected project and the current Codex
  thread. Persistent MCP calls must match their per-call thread identity to a
  short-lived capability; parent session identity cannot select a child inbox.
- Add bounded inbox waiting, exact-message acknowledgements and atomic,
  idempotent replies. Reading or waiting leaves messages unread until the
  receiving Agent explicitly acknowledges them.
- Generate a unique local plugin marketplace without changing account or
  global configuration. The App must load the plugin explicitly; its hooks
  guide the active session and do not wake a fully idle Codex App.
- Preserve existing transport ownership and keep the explicit socket probe
  read-only. Direct turn/start can target a loaded thread without resume, but
  an externally supported endpoint owned by the installed App remains unverified.

### Validation

Current-Mac original DSH Desktop acceptance confirms rc.6 plugin activation,
one bus-triggered real deepseek-official/deepseek-flash turn, one reply and one
ACK, with no manual prompt. Codex cooperation uses separate protocol, lifecycle
and original-App round-trip evidence. App plugin loading, idle wakeup, other
devices and business acceptance are distinct from these checks.

## 1.1.0-rc.6

### Summary

This preview makes the official Harness inbox acceptance observer tolerate
brief SQLite locks while another process updates the same isolated database.
It continues the existing preview channel and retains the rc.5 desktop bridge.

### Highlights

- Bound read-only acceptance queries with a busy timeout instead of failing
  immediately on transient contention. Preserve failures for invalid queries
  and locks that outlast the bound.
- Keep the rc.5 archive and tag immutable, including its original macOS
  acceptance failure receipt. This change does not alter product database
  policy, replay messages, or expand desktop endpoint access.

### Validation

An independent SQLite writer exercises a short held lock and the observer's
bounded wait. The release also retains separate source, installed-package,
official-runtime and actual Desktop acceptance boundaries.

## 1.1.0-rc.5

### Summary

This preview adds desktop Agent communication adapters: idle inbox wakeup for
existing DeepSeek Harness Agents, an opt-in bridge for one Claude Desktop Code
session, and a read-only probe for an explicitly selected Codex endpoint.
It continues the existing preview channel.

### Highlights

- Wake an idle live Harness Agent with external HCC messages through the official
  followup API. Poll every second by default; set `inboxPollMs` to `0` to disable
  idle wakeup. Preserve admission decisions and acknowledge only exact committed
  context. Self messages, rejected input and reload gaps cannot create retry loops.
- Generate a private Claude Desktop Mod with `hcc app claude serve`. Bind it to
  one project and existing session; record replies and acknowledgements together
  only after the matching main turn completes. Requires an embedded Claude Code
  engine of at least 2.1.287 and explicit plugin loading in that session.
- Preserve uncertain Claude deliveries across disconnects and restarts. Ordinary
  hooks cannot replay those inputs or replace an active Mod owner. Read-only
  inbox queries retain the unresolved messages for inspection.
- Inspect an explicitly supplied Codex Unix socket with `hcc app codex probe`.
  The probe does not start, resume or send to a thread, and does not establish
  that Desktop owns that endpoint. Codex Desktop sending remains unavailable.
- Include Chinese and English capability, setup and acceptance guidance. Keep
  the existing native CLI workers and their ownership boundaries.

### Validation

The implementation passed 1,825 local unit tests (two platform/privilege skips),
all 13 regression stages and five checks against the official Harness runtime
with deterministic localhost model responses. Merged-source CI also passed
Linux/macOS regression, Web and installed Harness package acceptance. These
checks do not establish real-model Desktop interoperability across all three
Apps. The generated Claude plugin and marketplace pass the official 2.1.289
strict validator. Device-specific results have separate receipts; the minimum
Desktop engine version remains a prerequisite.

## 1.1.0-rc.4

### Summary

This preview adds guarded forks for owned Codex and Claude sessions, durable
submission retries, and a persisted Codex read-only policy. It retains the
session isolation and shutdown fixes from rc.3.

### Highlights

- Fork an idle, owned Codex or Claude session into a distinct worker and provider
  session. Pending approvals, unresolved deliveries and changing parent bindings
  prevent a fork. DeepSeek Harness does not currently support native fork.
- Create Codex workers with `--sandbox read-only`. Resumes and forks retain the
  saved policy; approval escalation and HCC scoped MCP are disabled for these
  workers. Codex must confirm the policy before the worker becomes available.
  This is a provider filesystem sandbox, not an all-tools or network guarantee.
- Retry an unconfirmed Web submission with its original ID and message after
  reviewing its receipts. A later edited draft remains intact. Retries require
  current control and the original executor identity. Older pending records
  without the required identity remain available for manual review only.
- Persist the message and its retry identity together; repair the delivery
  record after interruption without creating a second message. Uncertain
  provider execution is never automatically replayed.
- Refresh late DeepSeek Harness tool input on the existing approval request,
  preserving its identity and oversized-input restrictions.
- Disable split views when the page lacks the browser session required by its
  embedded pane. Keep saved layouts for a later authenticated page.
- Distinguish the active runtime's clock observation from manual GC mutations
  in regression checks while requiring all other metadata to remain unchanged.

### Validation

Validation covers policy persistence, legacy-runtime refusal, fork inheritance,
submission recovery and browser retry behavior with later draft edits. Source,
installed-package, CI and real-provider results retain separate receipts; prior
historical connection-reset and provider failures are not reclassified by a
passing retry. Existing frozen release archives remain unchanged.

## 1.1.0-rc.3

### Summary

This preview integrates the multi-provider Web workbench with project Agent
settings, retained native history and project file editing. It also includes
session isolation and recovery fixes, shutdown quiescence and more precise
regression diagnostics. A new frozen package preserves the earlier rc.2 archive.

### Highlights

- Create Codex, Claude and DeepSeek Harness Agents from the Web workbench; retain
  project defaults, explicit native-history restore and directory-bound drafts.
- Upload project files and edit complete UTF-8 text with revision conflicts,
  preserved drafts and explicit readback after uncertain writes.
- Scope login cookies by trusted protocol and port so Web instances on different
  ports do not overwrite each other's login or logout state. Sign in again after
  upgrading; arbitrary SSH port remapping is not inferred.
- Keep the native-worker discovery error and refresh guidance when a restore
  receipt is absent, instead of failing inside the error handler.
- Stop admitting background work when administrator shutdown is accepted, then
  start cleanup after the HTTP response finishes or closes; preserve process
  identity checks, exit deadlines and independently owned workers.
- Recognize terminal regression markers split across output chunks and submit
  fixture input once. Isolate regression HTTP connections and test-owned ports.
- Add bounded CI task-dispatch and HTTP failure diagnostics without recording
  request bodies, credentials or query parameters, or retrying failed requests.

### Validation

Release checks compare the package file set, per-file hashes and modes with the
new frozen rc.3 archive. Source tests, browser checks and installed Harness checks
retain their exact commit and package receipts. The regression transport changes
isolate test fixtures; they do not establish the root cause of the earlier macOS
connection reset. Publication, current-device upgrades and real business calls
require separate evidence.

## 1.1.0-rc.2

### Summary

This local Web workbench candidate adds project Agent defaults, retained native
history with explicit closed-worker resume, and project file upload/editing.
It is based on the 1.0.5 delivery line and retains its process identity, tmux
snapshot and shutdown fixes. A local candidate does not establish publication.

### Highlights

- Create Codex, Claude and DeepSeek Harness background Agents from one Web form;
  save project defaults without changing provider credentials or global settings.
- Read HCC-retained native events and resume explicitly closed workers with
  owner, session and working-directory identity checks.
- Upload new project files up to 10 MiB and edit complete UTF-8 text up to 1 MiB,
  with revision conflicts, preserved drafts and explicit uncertain-write readback.
- Bind browser project requests and drafts to the selected directory identity.
- Preserve native Web connections and control tokens when background discovery
  overlaps Agent creation or history restore; discard stale discovery results.
- Recheck provider initialization before rejecting an older snapshot with no
  session ID, and retain exact project file matches when a wider search times out.
- Stop admitting background scans as soon as an administrator stop is accepted,
  and begin cleanup after its HTTP response finishes or closes. Keep existing
  process identity checks, exit confirmation deadlines and independent workers.
- Keep the existing terminal/App Server modes, readonly previews and bounded
  reconnect behavior.

### Validation

The candidate is checked with the full source regression suite, a disposable
npm installation and desktop/narrow browser flows. Real-provider entry and
history checks have separate receipts. These checks do not establish a public
release, a global installation upgrade or real business acceptance.

## 1.0.5

### Summary

macOS process identities use the kernel boot session UUID so changes to the
reported boot time cannot make a running process appear to have been replaced.
The issue was observed during post-release sustained acceptance of 1.0.4.

### Highlights

- Preserve process identity across changes to the wall-clock-derived boot time.
- Keep live processes with an older Darwin identity format protected while their
  ownership cannot be compared; a format change does not prove that an owner exited.
- Retain strict process state, start time and zombie checks, with unknown results
  when a stable boot session identifier cannot be read.
- Keep the existing npm `latest` release channel.
- Confirm the original local runtime has exited when its stop response is lost,
  while preserving unknown owners and replacement runtime pointers.
- Retain structured shutdown error codes when Node warnings share stderr.

### Validation

Targeted regression tests cover boot identity drift, boot-session changes,
malformed observations and conservative handling of existing runtime ownership.
Full source, package, current-device and sustained-run validation are recorded
separately. The interrupted 1.0.4 sustained run remains a failed attempt.
The first 1.0.5 candidate passed the current-Mac sustained check; a subsequent
CI transport timeout exposed the separate stop-confirmation failure. Its
targeted verification and replacement candidate retain separate evidence.

Existing processes keep the implementation they started with. Quit and reopen
Harness normally to activate the update. An older active owned runtime should
finish and stop normally before it is reclaimed; do not force takeover based
on an incompatible identity marker.

## 1.0.4

### Summary

Session lists no longer run synchronous tmux client probes for each displayed
terminal. A bounded asynchronous snapshot supplies display information while
live process and terminal observations continue to guard control actions.

### Highlights

- Share one short-lived tmux display snapshot across sessions. Cold, stale or
  failed observations remain unknown, and pending probes stop with the runtime.
- Preserve live checks for terminal control, rebind, stop and ownership.
- Treat exited macOS zombie processes as dead, so shutdown waits can complete
  while a parent has yet to reap the PID; malformed observations remain unknown.
- Include the HTTP method, request path, deadline and elapsed time in runtime
  request failures, without request bodies, query parameters or credentials.
- Keep DeepSeek Harness on the existing npm `latest` channel.

### Validation

Targeted tests cover slow probes, stale and failed snapshots, refresh coalescing,
shutdown and request diagnostics. Full regression, official installed Harness,
registry readback and current-Mac model checks have separate verification records.
The earlier 1.0.3 macOS CI timeout remains historical evidence: removing a known
blocking path does not identify the specific cause of that earlier timeout.
Regression shutdown tracks the exact fixture process identity, distinguishes
reused PIDs and zombies, and retains bounded failure diagnostics before cleanup.

## 1.0.3

### Summary

This maintenance release keeps DeepSeek Harness on the normal npm `latest`
channel and repairs the CLI, native-session and Web regressions identified while
archiving 1.0.2. It retains the verified Cordis cleanup and recovery behavior.

### Highlights

- Preserve provider process identity during registration and discovery; update
  owned hooks without discarding unrelated hooks or damaged user configuration.
- Keep explicit hook database routing and quote generated terminal arguments.
- Preserve the recorded origin of native submissions across restarts; peer
  messages cannot gain local-user authority from their sender name or text.
- Keep managed state directories and database files private without replacing
  existing data or changing external database parent permissions. Terminal stream
  buffers follow each session's project.
- Bound streaming updates and long-message rendering while preserving complete
  copied content, reader position, approval details and session ownership checks.
- Isolate request parsing failures, retain local/proxy access contracts, serialize
  Web startup and resolve terminal assets with npm dependency hoisting.
- Native runtime ownership uses alternate ports for identifiable unrelated local
  listeners while keeping one owner per project. Silent or legacy listeners are
  rejected conservatively, and ownership remains until shutdown completes.

### Validation

The full restored regression suite and the installed official Harness package
checks run against this composed release. The frozen file manifest and verification
record live under `docs/verification/`; those source-only records are excluded
from the npm package. Publication, current-device activation and real-model
acceptance are recorded separately from source and CI checks.

## 1.0.2

### Summary

DeepSeek Harness now joins hello-cc through project hooks, a Cordis collaboration
bundle, and owned ACP workers. This release promotes the runtime verified in
`1.0.2-dsh.3` to the normal npm `latest` channel. Runtime code is unchanged from
that candidate; version metadata and release documentation identify this release.

### Highlights

- Harness Agents use their exact session and project identity for task, message,
  lock, result, and handoff operations. Context acknowledgements follow committed
  model input, and permission decisions retain the Harness policy chain.
- Owned ACP workers support queued prompts, scoped MCP tools, approvals,
  interruption, session resume, and shutdown through the CLI and Web interface.
- Managed project configuration migrates verified paths from source checkouts to
  installed packages while preserving user edits.
- Cordis sessions recover after a verified owner process exits; transient
  database failures during retirement remain retryable while old tool authority
  is revoked immediately.
- Node.js 24+ and official Harness `0.2.0-rc.2` are required. Supported hosts are
  macOS and Linux; Windows uses WSL. Native Windows shells are not supported.

### Validation

The byte-identical preview runtime passed macOS real-model installation checks
(11), Linux container installation and deterministic collaboration checks (8 + 7),
and frozen-package recovery tests (17). Its registry download and all 216
installed files matched the candidate. This stable package receives independent
release, installation, and registry readback checks. Other-device and genuine
business acceptance remain separate stages.

## 1.0.2-dsh.3

### Summary

This preview keeps the DeepSeek Harness integration introduced in `1.0.2-dsh.2`
and fixes session cleanup when a temporary database failure interrupts shutdown.
It remains an npm `dsh` preview and a GitHub prerelease.

### Highlights

- Revoking a Cordis Agent immediately blocks its tools while allowing database
  retirement to retry after storage becomes available again.
- Preserve failed cleanup records across plugin reloads. Recovery requires the
  exact disposed Agent, provider session, and project; active owners cannot be
  replaced based on another Agent's disposal event.
- Retain the pinned Harness `0.2.0-rc.2`, Node.js 24+, and Linux/macOS/WSL support
  boundaries. Every candidate has independent package and acceptance receipts.

## 1.0.2-dsh.2

### Summary

This preview integrates DeepSeek Harness sessions with the hello-cc task,
message, lock, and handoff services. It adds project hooks, an installed Cordis
bundle, and owned ACP workers, including session recovery and explicit approval
handling. The preview is intended for the `dsh` npm dist-tag and a GitHub
prerelease; publication and business acceptance are separate delivery gates.

### Highlights

- `hcc dsh setup`, `status`, and `web` manage project hooks or a Cordis overlay.
  Setup verifies its managed files before migrating paths from a source checkout
  to an installed package and preserves user-edited configuration.
- The Cordis bundle exposes collaboration tools using each Agent's complete
  provider session ID and project root. Inbox acknowledgements follow the
  committed model context; simultaneous sessions retain separate ownership.
- A resumed Cordis session can reclaim ownership after a crashed owner only
  when complete process identity evidence confirms that owner is dead. Live or
  uncertain owners, competing transports, and changed bindings remain protected.
- Native ACP workers use a dedicated `dsh --profile acp` process with scoped MCP
  tools. Queue admission and completed delivery are distinct; close, resume,
  interruption, and approval responses retain the owning session boundary.
- ACP approval requests correlate tool-call IDs with their tool input, including
  out-of-order updates. Requests with missing or truncated context cannot be
  accepted; rejection remains available.
- Release tooling derives GitHub prerelease status from the version and exposes
  it during dry runs, so preview releases do not receive stable release status.

### Compatibility Notes

- Node.js 24 or newer and matching DeepSeek Harness `0.2.0-rc.2` runtime packages
  are required. The Cordis integration checks the actual Agent, AgentLoop, Tools,
  and Sessions package versions before loading.
- Supported host environments are Linux and macOS; Windows users must use WSL.
  Native Windows shells are not supported. The existing macOS arm64 acceptance
  results do not establish Linux, WSL, or other-device acceptance for this preview.
- Choose one injection method per Harness process: profile bundle or project
  overlay. Harness manages profile bundle installation; `setup --mode off`
  disables a managed project overlay.
- Existing schema v7 and Runtime API v2 boundaries still apply. Real model
  acceptance requires a provider route that permits Harness; a route restricted
  to an official client remains restricted.

### Validation

Earlier local macOS arm64 candidates completed official plugin installation and
removal, real Cordis collaboration calls, ACP session lifecycle and approval
denial, and an isolated order-report workflow. Those dated receipts belong to
their recorded candidate hashes. This version requires its own frozen-package
installation receipt and release checks before publication. Other-device
installation and genuine business signoff remain separate, incomplete gates.

## 1.0.1

### Summary

hello-cc 1.0.1 is a file-lock determinism, buffer-GC safety, fresh-install, and
release-reliability patch. It makes worker shutdown reclaim kernel lock
endpoints deterministically when an identity probe keeps its client write half
open, restores real PTY startup in fresh macOS npm installations, and keeps
automatic GC fail-closed when optional buffer paths disappear or change.

### Highlights

- The socket-lock worker now tracks each locally accepted socket and destroys
  those accepted handles during server shutdown, so release no longer depends
  on the peer closing its writable half after reading the lock banner.
- A real half-open identity-probe regression verifies that release returns
  promptly, a nonblocking reacquisition succeeds immediately, and the probe is
  explicitly stopped and awaited during final cleanup.
- `node-pty` is exactly pinned to `1.2.0-beta.15`. The stable `node-pty 1.1.0`
  npm artifact contains non-executable Darwin helpers, which makes a fresh
  macOS install fail with `posix_spawnp failed`; the selected artifact publishes
  both Darwin helpers with executable modes.
- Linux, macOS, and WSL installation instructions now list Node.js 24, tmux
  commands for the major system package managers, CLI verification, and safe
  handling for npm global-install permission errors.
- `hcc down` now waits for the exact Runtime process identity to exit before it
  reports success, including safe handling for PID reuse and a bounded timeout
  when shutdown cannot be confirmed.
- Background Web startup keeps its immediate child-exit failure but allows a
  bounded 60-second health window, avoiding false failures on loaded macOS CI
  hosts where process identity and project restoration can exceed 30 seconds.
- Manual buffer GC allows a bounded 30-second window for runtime evidence
  planning and apply, while still deferring all eligible files if the runtime
  remains unavailable.
- Automatic GC now treats a missing `.hello-cc/bufs` leaf as empty without
  recreating it. A missing state directory, a symlinked path component, an
  inode replacement, or a retargeted project-root alias fails closed with
  `PROJECT_PATH_FORBIDDEN` before buffer, clock, lock, or history mutation.
- Buffer path identity is retained through evidence collection, lease
  acquisition, planning, clock reads, and database transactions. GC uses a
  no-create lease while existing file-lock callers retain their original
  parent-creation behavior.
- Per-connection Web action tokens now require their issuing terminal socket to
  still be open, closing the handshake race before asynchronous token cleanup.
- Runtime request deadlines now reach the underlying HTTP transport, and peer
  start/attach preflight and mutation requests use a bounded 60-second window
  while stop and terminal-input operations use 30 seconds, instead of all
  inheriting the shorter read-request default.

### Compatibility Notes

- No CLI command or package-surface behavior changes are intended. Schema v7,
  Runtime API v2, the authenticated browser's ability to choose any existing
  server directory as a project root, and the 1.0.0 accepted-risk boundaries
  are unchanged.
- Stable project-root aliases remain supported. Only path disappearance,
  replacement, symlink traversal, or alias retargeting during GC is rejected.
- The existing five-second fail-closed deadline and cleanup-error behavior are
  unchanged.
- `node-pty@1.2.0-beta.15` is a bounded prerelease dependency risk. The exact
  pin prevents unreviewed beta movement, and release tests verify the installed
  version, regular-file identity, executable modes, and a real PTY. There is no
  postinstall or CI-only `chmod` workaround.

### Validation

The 1.0.1 release gate includes repeated macOS Node 24 tests; a no-cache Linux
Node 24/tmux image build followed by three complete `npm test` runs in that same
image, each ending with `FULL_REGRESSION_OK`; and a fourth clean container that
installs the same 1.0.1 package tarball and passes PTY, database, Web, and
missing-buffer GC smoke checks. Fresh macOS consumer installs pass both normal
and `--ignore-scripts` installation, proving that executable helper modes come
from the package artifact rather than lifecycle-script mutation. GC regression
coverage includes absent optional leaves, symlink and ancestor replacement,
alias retargeting, no-create lock acquisition, and path guards around clock and
history writes.

## 1.0.0

### Summary

hello-cc 1.0.0 is a breaking data, identity, and Runtime API release. It makes
process identity the authority for session liveness, bounds unknown evidence,
and hardens browser terminal control and technical-state cleanup.

### Highlights

- Process identity now controls live/dead decisions across tmux and ordinary
  child processes, including sleep, detach, PID reuse, and stale status rows.
- Browser credentials, trusted proxy headers, Runtime API TLS, and buffer GC
  all have narrower, tested authority boundaries.

### Breaking Changes

- Databases upgrade to schema v7. Downgrading a migrated database is not
  supported. Before migration, hello-cc creates a verified
  `<db>.pre-v<from>-to-v7.<timestamp>.<suffix>.bak` snapshot; stop all hello-cc
  processes and validate the backup with SQLite `quick_check` before any manual
  recovery. At most five strictly named backups are retained per database; the
  recovery procedure is documented in the user guide.
- Provider peer IDs now hash the complete provider session value. Existing
  pre-v1 provider IDs and bindings are left unchanged: there is no automatic
  alias, graph rewrite, or migration to the new ID.
- Protected HTTP and WebSocket operations require Runtime API v2. Browser
  terminal write tokens are issued per WebSocket connection and revoked when
  that connection closes.

### Security And Reliability

- Live tmux and non-tmux sessions are decided from immutable process evidence;
  sleep and tmux detachment do not mark a live process dead. Unknown evidence
  receives at most 120 seconds of grace, while confirmed dead owners expire.
- Generated Web access tokens are scoped to one runtime and are not persisted.
  HTTPS runtime overrides use normal certificate verification; set
  `HCC_RUNTIME_CA` to a CA file for a private or self-signed endpoint.
- `--trust-proxy` now requires `--proxy-origin https://host[:port]`; forwarded
  scheme and host must match that fixed origin and arrive from loopback.
- Garbage collection keeps task/message/event/handoff history unless
  `hcc gc --history --yes` is explicitly requested. Buffer deletion rechecks
  producer evidence and leases immediately before each bounded batch.

### Accepted Risks

- The default Web listener remains `0.0.0.0` over plaintext HTTP for trusted
  LAN use. The token controls access but does not provide transport encryption;
  use `--tls` or a pinned TLS reverse proxy when the network is not trusted.
- An authenticated browser may select any existing server directory as a
  project root. This is intentional for the operator console and is not a
  project-root sandbox or tenant boundary.

### Validation

The release gate requires Node 24 unit and full regression tests, package import
closure checks, a fresh Docker build, and three consecutive container runs that
end with `FULL_REGRESSION_OK`.

## 0.1.9

### Summary

hello-cc 0.1.9 publishes the post-0.1.8 Web runtime and provider shim
hardening work. It tightens Web peer action identity, makes runtime cleanup
safer, and keeps Claude/Codex shims from attaching unrelated projects to a
global Web runtime.

### Highlights

- Hardened Web runtime cleanup so starting `hcc web` from a wrapper shell does
  not terminate the current parent process chain while still removing stale
  orphan runtimes for the same project.
- Returned structured `BAD_REQUEST` JSON for malformed Web API request bodies
  instead of surfacing raw JSON parse failures.
- Replaced Web-runtime-token reuse for mutating peer actions with independent
  per-session action tokens.
- Changed provider shims to fall back to the real Claude/Codex CLI when no
  current-project Web runtime is available.
- Made provider shims use only the current project's `.hello-cc/runtime.json`
  during managed launches, avoiding accidental attachment through a global Web
  runtime from another project.
- Kept shim-only environment variables out of restarted provider sessions.

### Compatibility Notes

- No breaking CLI command changes are intended in this release.
- `hcc web --local` is still Web mode; use `hcc up` when you only want local
  coordination commands without the Web console or shims.
- Starting `claude` or `codex` in a directory without a local
  `.hello-cc/runtime.json` now runs the real provider CLI instead of implicitly
  using a global hello-cc Web runtime.

### Validation

The 0.1.9 release should be validated with:

```bash
git diff --check
node --check bin/hcc.mjs
find lib -name '*.mjs' -print0 | xargs -0 -n1 node --check
node --check scripts/github-release.mjs
node --check scripts/regression.mjs
node --check scripts/release-notes.mjs
npm run release:check
npm run release:github:dry-run -- --version 0.1.9
npm pack --dry-run --json
npm publish --dry-run --registry=https://registry.npmjs.org/ --access public
npm test
```

The expected full regression marker is:

```text
FULL_REGRESSION_OK
```

## 0.1.8

### Summary

hello-cc 0.1.8 is a targeted patch release for Claude/Codex shim
self-repair. It fixes generated shims that could stay pinned to a removed
provider binary after Claude or Codex was reinstalled.

### Highlights

- Fixed `hcc shim ensure` so it only reuses an existing `# Real binary:` path
  when that binary still exists.
- Preserved the existing fast path for valid generated shims while falling back
  to the requested binary or rediscovering the provider from `PATH` when the
  recorded path is stale.
- Added regression coverage for the reinstall case where a generated shim
  points at a deleted provider binary but a working provider is available on
  `PATH`.

### Compatibility Notes

- No CLI command or package surface changes are intended in this release.
- Existing generated shims will self-heal on the next `hcc shim ensure` or shim
  launch when their recorded provider binary has disappeared.

### Validation

The 0.1.8 release should be validated with:

```bash
git diff --check
node --check bin/hcc.mjs
find lib -name '*.mjs' -print0 | xargs -0 -n1 node --check
node --check scripts/github-release.mjs
node --check scripts/regression.mjs
node --check scripts/release-notes.mjs
npm run release:check
npm run release:github:dry-run -- --version 0.1.8
npm pack --dry-run --json
npm publish --dry-run --registry=https://registry.npmjs.org/ --access public
npm test
```

The expected full regression marker is:

```text
FULL_REGRESSION_OK
```

## 0.1.7

### Summary

hello-cc 0.1.7 publishes the post-0.1.6 Web and coordination hardening work
alongside the README product screenshot. It keeps the 0.1.6 package surface and
adds stricter peer identity behavior, audited Web peer actions, cleaner tmux
test isolation, and clearer first-run documentation for the Web console.

### Highlights

- Enforced system-peer identity handling so internal coordination actions stay
  attributable and do not accidentally inherit a user peer identity.
- Audited Web peer action flows and expanded regression coverage around task,
  message, lock, and tmux cleanup paths used by the browser console.
- Cleaned tmux-focused regression tests so runtime cleanup and test isolation
  stay stable across repeated local runs.
- Added a sanitized Web console screenshot to both English and Chinese README
  files, showing sessions, terminal output, project state, messages, peers,
  tasks, and locks.
- Documented that `hcc web` defaults to a LAN-facing `0.0.0.0` bind, requests
  port `8787`, prints both `open:` and `local:` token URLs, and auto-tries later
  ports when `--port` is not explicit.

### Compatibility Notes

- No breaking CLI command changes are intended in this release.
- The Web access model remains token-in-URL based; use `--local` when the Web
  console should bind only to `127.0.0.1`.
- This release does not change the public package surface introduced in 0.1.6.

### Validation

The 0.1.7 release should be validated with:

```bash
git diff --check
node --check bin/hcc.mjs
find lib -name '*.mjs' -print0 | xargs -0 -n1 node --check
node --check scripts/github-release.mjs
node --check scripts/regression.mjs
node --check scripts/release-notes.mjs
npm run release:check
npm run release:github:dry-run -- --version 0.1.7
npm pack --dry-run --json
npm publish --dry-run --registry=https://registry.npmjs.org/ --access public
npm test
```

The expected full regression marker is:

```text
FULL_REGRESSION_OK
```

## 0.1.6

### Summary

hello-cc 0.1.6 publishes the current architecture-layout cleanup that followed
0.1.5 and records the split-stack audit that reviewed it. The installed CLI
behavior remains the public API, while internal helpers now live closer to their
product boundaries under `core/`, `runtime/`, `web/`, `terminal/`,
`integrations/`, `ui/`, `release/`, and `shared/`. This release keeps the
current master history as the publish path; teams that want cleaner refactor
history should use the documented rebuild-branch option instead.

### Highlights

- Added architecture guidance for the target module layout and documented the
  package-surface policy: `hcc` and `hello-cc` are the supported public
  interfaces; deep `lib/` imports are compatibility paths, not user workflows.
- Added `docs/layout-split-stack-audit.md`, which classifies the local
  `origin/master..HEAD` stack, calls out the early flat-helper extraction phase,
  and records the package-surface and follow-up cleanup decisions before
  publish.
- Moved peer, task, lock, message, team, timeline, automation, and session
  helpers into `core/`, `db/`, `runtime/`, `terminal/`, and `integrations/`
  boundaries while keeping compatibility entrypoints for already-exposed paths.
- Moved Web runtime, HTTP, UI template, and peer action helpers into `lib/web/`
  while preserving existing Web console behavior.
- Moved provider command helpers and Claude/Codex hook and shim setup helpers
  into `lib/integrations/`, including shim script generation under
  `lib/integrations/shims/`.
- Moved JSON and CLI error helpers into `lib/shared/`, release metadata helpers
  into `lib/release/`, and CLI-facing state/help rendering into `lib/ui/`.
- Expanded regression guards so module moves verify both the new primary
  boundary and the compatibility re-export identity.

### Compatibility Notes

- `@logicseek/hello-cc@0.1.5` was already published from git head `4969100`.
  This release uses a new package version and does not republish `0.1.5`.
- Top-level `lib/*.mjs` files that were already published in `0.1.5` remain
  available for this release cycle to avoid breaking deep imports exposed by the
  package's `files` list.
- New top-level re-export-only helper paths introduced during the local layout
  migration are treated as compatibility-only deep-import paths for this
  release, not as target architecture. New code should prefer the
  product-boundary modules documented in `docs/architecture.md`.
- The audit records remaining cleanup items for later focused work, including
  moving SQL-heavy task store operations out of pure core, removing core/runtime
  reverse dependencies on top-level formatting or Web helpers, and continuing to
  split `cmdWeb()` by subsystem instead of by incidental helper names.
- No breaking CLI command changes are intended in this release.

### Validation

The 0.1.6 release should be validated with:

```bash
git diff --check
node --check bin/hcc.mjs
find lib -name '*.mjs' -print0 | xargs -0 -n1 node --check
node --check scripts/github-release.mjs
node --check scripts/regression.mjs
node --check scripts/release-notes.mjs
npm run release:check
npm run release:github:dry-run -- --version 0.1.6
npm pack --dry-run --json
npm publish --dry-run --registry=https://registry.npmjs.org/ --access public
npm test
```

The expected full regression marker is:

```text
FULL_REGRESSION_OK
```

## 0.1.5

### Summary

hello-cc 0.1.5 publishes the Web runtime split that landed after 0.1.4. The
CLI keeps the same user-facing Web behavior, while runtime URLs, request
parsing, HTTP response helpers, and the browser UI template now live in focused
`lib/` modules. This release also includes the latest coordination automation
improvements for stale task owners, batch task claims, and takeover-ready task
state.

### Highlights

- Added batch task claiming and takeover policy support for blocked or stale
  work, including owner liveness details in task/state output.
- Fixed detected-peer Web controls so active `working` or `idle` peers show the
  correct stop action instead of being treated as restart-only peers.
- Kept stop-dialog labels tied into Web i18n so language changes update the
  dialog controls consistently.
- Extracted Web runtime URL/token helpers into `lib/web-runtime.mjs`.
- Extracted the browser UI template into `lib/web-ui-template.mjs`.
- Extracted low-level Web HTTP helpers into `lib/web-http.mjs`.
- Expanded regression coverage for the new helper modules, packaged module
  contents, Web display guards, and release/package checks.

### Validation

The 0.1.5 release should be validated with:

```bash
git diff --check
node --check bin/hcc.mjs
node --check lib/web-http.mjs
node --check lib/web-runtime.mjs
node --check lib/web-ui-template.mjs
node --check scripts/github-release.mjs
node --check scripts/regression.mjs
node --check scripts/release-notes.mjs
npm run release:check
npm run release:github:dry-run -- --version 0.1.5
npm pack --dry-run --json
npm publish --dry-run --registry=https://registry.npmjs.org/ --access public
npm test
```

The expected full regression marker is:

```text
FULL_REGRESSION_OK
```

## 0.1.4

### Summary

hello-cc 0.1.4 publishes the latest Web coordination fixes and a small internal
module split. The Web console now uses structured peer action APIs instead of
injecting routine action commands into the terminal, keeps Project State card
scroll positions stable through refreshes, and refreshes restored tmux panes
after browser input. Release and guidance helpers are now shared from `lib/`,
so CLI metadata, release-note parsing, GitHub release publishing, and generated
coordination guidance have one source of truth.

### Highlights

- Added `/api/peers/:peer/actions/:action` for Web status, state, inbox,
  task-claim, heartbeat, and registration actions, with an action-result panel
  in the browser UI.
- Kept explicit terminal command injection available only for the advanced
  terminal status action, so normal Web toolbar actions no longer modify the
  selected session's terminal input.
- Added collapsible Project State cards for automation, timeline, messages,
  peers, tasks, and locks, with persisted collapsed state and restored per-card
  scroll positions after polling refreshes.
- Refreshed tmux snapshots shortly after WebSocket input so restored tmux
  sessions show typed input promptly without unsafe browser-side local echo.
- Disabled stale tmux `pipe-pane` writers before restoring FIFO streaming, so
  restarted Web runtimes can attach to existing panes reliably.
- Moved package metadata, changelog release helpers, and generated coordination
  guidance into reusable `lib/` modules used by the CLI and release scripts.
- Expanded regression coverage for Web peer actions, state-card behavior,
  tmux input visibility, packaged helper modules, v-prefixed release-note
  versions, and CLI/package version consistency.

### Validation

The 0.1.4 release should be validated with:

```bash
git diff --check
node --check bin/hcc.mjs
node --check lib/guidance.mjs
node --check lib/package-meta.mjs
node --check lib/release-notes.mjs
node --check scripts/github-release.mjs
node --check scripts/regression.mjs
node --check scripts/release-notes.mjs
npm run release:check
npm run release:github:dry-run -- --version 0.1.4
npm pack --dry-run --json
npm publish --dry-run --registry=https://registry.npmjs.org/ --access public
npm test
```

The expected full regression marker is:

```text
FULL_REGRESSION_OK
```

## 0.1.3

### Summary

hello-cc 0.1.3 improves the Web console for day-to-day remote operation and
hardens the release workflow. The Web UI now supports English/Chinese labels,
resizable left and right sidebars, remote token defaults, and a cleaner
resume/session experience. Release notes can now be published automatically from
the changelog through GitHub Actions, so tag-based releases and manual backfills
use the same checked release body.

### Highlights

- Added a Web language selector with English and Chinese labels for the main
  project/session controls, action menu, state panel, detected-session view, and
  status text.
- Added full-height draggable left and right sidebar dividers while preserving
  the compact collapse buttons and persisted sidebar widths.
- Reapplied sidebar width clamps after collapse/expand transitions so restored
  panels cannot squeeze the center terminal below its usable width.
- Kept bare `hcc web` remote-friendly by default with a saved token, while
  preserving `--local` and explicit token/no-token controls.
- Added provider resume controls and resumable-session selection in the Web
  start form so Claude/Codex resume flows are available from the browser.
- Added `scripts/github-release.mjs` plus `release:github` and
  `release:github:dry-run` npm scripts to create or update GitHub Releases from
  `CHANGELOG.md`.
- Added `.github/workflows/github-release.yml` so pushing `v*` tags publishes
  the GitHub Release description with the repository `GITHUB_TOKEN`, and
  `workflow_dispatch` can backfill older releases without a personal token.
- Tightened generated coordination guidance so read-only reviews do not take
  advisory locks and mutating work remains explicitly locked.
- Expanded regression coverage for Web i18n, sidebar resizing, release notes,
  GitHub Release automation, and generated coordination guidance.

### Validation

The 0.1.3 release should be validated with:

```bash
git diff --check
node --check bin/hcc.mjs
node --check scripts/regression.mjs
node --check scripts/github-release.mjs
node --check scripts/release-notes.mjs
npm run release:check
npm run release:github:dry-run -- --version 0.1.3
npm pack --dry-run --json
npm publish --dry-run --registry=https://registry.npmjs.org/ --access public
npm test
```

The expected full regression marker is:

```text
FULL_REGRESSION_OK
```

## 0.1.2

### Summary

hello-cc 0.1.2 tightens the public release surface after the first scoped npm
publish. It adds a first-class update command, makes uninstall discoverable in
top-level help, and reorganizes the documentation so the npm package page and
GitHub release notes have a clear, detailed description of what changed. It also
adds explicit team task orchestration and makes schema migrations cover
registered project databases.

### Highlights

- Added `hcc update`, which updates the global npm install by running
  `npm install -g @logicseek/hello-cc@latest`.
- Added `hcc update --tag`, `hcc update --registry`, and `hcc update --dry-run`
  for controlled upgrades and release verification.
- Made `hcc uninstall` visible in top-level `hcc --help`, matching the README
  and command reference.
- Kept uninstall behavior conservative: `hcc uninstall` removes hooks and
  shims, while `hcc uninstall --purge --yes` is required to remove project data.
- Split documentation into a short README, a user guide, command reference, and
  documentation index in both English and Chinese.
- Added `hcc team plan`, `hcc team start`, and `hcc team status` for explicit
  parent-task splits into auditable child tasks.
- Added task hierarchy metadata so team subtasks remain visible through the
  normal task/state/timeline surfaces.
- Extended schema migration startup so registered project databases are migrated
  alongside the current project database when the CLI opens state.
- Changed bare `hcc web` to listen on `0.0.0.0` with a saved URL token by
  default. The token is generated on first use and reused across restarts; use
  `--local` for loopback-only access or `--no-token` only in trusted local/test
  environments.
- Restored the Star History chart at the bottom of both README files.
- Included README-linked package assets in the npm tarball so the package page
  renders the project logo correctly.

### Documentation

- `README.md` and `README.zh-CN.md` now focus on product positioning, install
  and maintenance commands, quick start, a basic workflow, and links to docs.
- `docs/guide.md` and `docs/guide.zh-CN.md` describe practical usage and avoid
  embedding the full command list.
- `docs/commands.md` and `docs/commands.zh-CN.md` provide the compact command
  reference.
- `docs/README.md` and `docs/README.zh-CN.md` provide the documentation index.
- English documentation links now point to English user docs, and Chinese
  documentation links point to Chinese user docs.

### Validation

The 0.1.2 release should be validated with:

```bash
git diff --check
node --check bin/hcc.mjs
node --check scripts/regression.mjs
node --check lib/setup.mjs
node --check lib/discover.mjs
npm pack --dry-run --json
npm publish --dry-run --registry=https://registry.npmjs.org/ --access public
npm test
```

The package dry run should include `CHANGELOG.md`, `assets/logo.svg`, and the
English and Chinese command reference files.

The expected full regression marker is:

```text
FULL_REGRESSION_OK
```

### Release Notes Source

Use this changelog section as the source for the GitHub Release notes for
`v0.1.2`. The npm package metadata keeps a short description, while the package
README and this changelog provide the detailed release description.

Publish or backfill the GitHub Release description with:

```bash
GH_TOKEN=... npm run release:github -- --version 0.1.2
```

After `.github/workflows/github-release.yml` is on the default branch, the same
backfill can be run from GitHub Actions with `workflow_dispatch` and version
`0.1.2`, without a personal token.
