import type { Context } from '@deepseek-ai/cordis';
import type { ContextFormed } from '@deepseek-ai/dsh-llm';

export interface DshCollaborationConfig {
  /** Bounded model context, 2048-64000 characters. Default 16000. */
  maxContextChars?: number;
  /** Bounded lossless-JSON tool presentation, 2048-64000 characters. Default 16000. */
  maxToolChars?: number;
  /** Idle inbox poll interval, 100-60000 ms. Default 1000; 0 disables automatic idle wakeup. */
  inboxPollMs?: number;
}
export const name: 'hello-cc-dsh-collaboration';
export const inject: readonly ['agents', 'tools', 'sessions'];
export const DSH_CORDIS_VERSION: '0.2.0-rc.2';
export const DSH_SUPPORTED_VERSIONS: readonly ['0.2.0-rc.2', '0.2.1-rc.3'];
export function checkDshRuntime(anchor?: string): typeof DSH_SUPPORTED_VERSIONS[number];
export function apply(ctx: Context, config?: DshCollaborationConfig): void;
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'hello-cc': { readonly kind: 'hello-cc' } & ContextFormed;
  }
}
