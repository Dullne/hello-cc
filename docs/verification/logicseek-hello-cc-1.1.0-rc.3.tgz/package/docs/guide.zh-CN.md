# hello-cc 用户指南

这份文档说明安装、启动和日常使用流程。紧凑命令清单见
[命令参考](commands.zh-CN.md)。

## v1 升级契约

1.0.0 会在生成并校验迁移前备份后升级到 schema v7，且不支持降级。provider
peer ID 已变更，不会映射旧 ID；受保护接口要求 Runtime API v2。存活判断以进程
证据为先，只有 unknown 证据获得 120 秒宽限。历史 GC 必须显式使用
`--history`。需要加密时使用 `--tls`，或
`--trust-proxy --proxy-origin ORIGIN`。可信内网明文模式和已认证浏览器选择任意
已存在服务器目录，仍是明确接受的风险。

### 从迁移前备份恢复

hello-cc 为每个数据库最多保留 5 份经校验的迁移备份。如果必须回退一次 v1
迁移，先停止 Web runtime，以及所有仍可能访问该项目的 hello-cc/provider 进程。
校验选定备份，把失败数据库及其 WAL/SHM 文件改名保留，再发布备份的私有副本：

```bash
db=/path/to/project/.hello-cc/mesh.db
backup=/path/to/project/.hello-cc/mesh.db.pre-v6-to-v7.<timestamp>.<suffix>.bak
sqlite3 "$backup" 'PRAGMA quick_check;'
cp -p "$backup" "$db.restore"
chmod 600 "$db.restore"
mv "$db" "$db.failed-v7.<recovery-id>"
test ! -e "$db-wal" || mv "$db-wal" "$db-wal.failed-v7.<recovery-id>"
test ! -e "$db-shm" || mv "$db-shm" "$db-shm.failed-v7.<recovery-id>"
mv "$db.restore" "$db"
```

校验结果必须是 `ok`。确认恢复后的项目正常前，不要删除这些改名文件。再次启动
v1 会把恢复的数据库重新迁移到 schema v7；用旧版本 hello-cc 打开恢复出的 pre-v1
数据库不属于受支持的降级路径。

## 安装、更新和卸载

### 前置依赖

通过 Node.js 官方软件包或 Node 版本管理器安装 Node.js 24 或更新版本。浏览器可
控制的终端还需要 `tmux`：

```bash
# Debian / Ubuntu
sudo apt-get update
sudo apt-get install -y tmux
# Fedora / RHEL
sudo dnf install -y tmux
# 旧版 RHEL / CentOS
sudo yum install -y tmux
# Alpine
sudo apk add tmux
# Arch Linux
sudo pacman -S --needed tmux
# openSUSE
sudo zypper install tmux
# 仅 macOS
brew install tmux
```

Linux 必须使用当前发行版的系统包管理器，而不是 Homebrew。root shell 可以省略
`sudo`。WSL 用户应在 WSL 内部按对应 Linux 发行版安装；不支持原生 Windows
shell。

当存在受支持的包管理器且权限足够时，`hcc web` 可以尝试自动安装 tmux。对于
服务器、容器和非交互式 sudo 环境，手动安装是确定性更高的方式。

### 安装和验证

全局安装 hello-cc：

```bash
npm install -g @logicseek/hello-cc
```

如果 npm 报 `EACCES`，请使用 Node 版本管理器或配置用户自有的 npm prefix。
不要使用 `sudo npm install -g`，否则可能产生 root 所有的包和配置文件。

验证全部前置依赖和 CLI：

```bash
node --version
npm --version
tmux -V
hcc --version
hcc --help
```

Node 版本应为 `v24` 开头或更高主版本；启动托管终端前，上述命令都应成功退出。

不全局安装时可以使用：

```bash
npx @logicseek/hello-cc web
```

### 更新和卸载

更新已有的全局安装：

```bash
hcc update
```

`hcc update` 会执行 `npm install -g @logicseek/hello-cc@latest`。使用
`hcc update --help` 可以查看更新选项。`hcc task update` 更新的是协作任务状态，不是安装包版本。

移除本机 hooks、shims 和 shell PATH 配置：

```bash
hcc uninstall
```

同时移除当前项目的 `.hello-cc` 数据和指导块：

```bash
hcc uninstall --purge --yes
```

移除全局 npm 包：

```bash
npm uninstall -g @logicseek/hello-cc
```

## 默认入口

在项目目录运行：

```bash
cd /path/to/project
hcc web
```

`hcc web` 会自动完成：

1. 在当前目录初始化 `.hello-cc/mesh.db`
2. 写入受控项目指导块：`.hello-cc/HCC.md`、`CLAUDE.md`、`AGENTS.md`
3. 安装或刷新 Claude Code hooks：`~/.claude/settings.json`
4. 安装或刷新 Codex hooks：`~/.codex/hooks.json`
5. 安装 `~/.hcc-shims/claude` 和 `~/.hcc-shims/codex`
6. 将 `~/.hcc-shims` 加入 shell PATH
7. 检查 `tmux`，缺失时尽量自动安装；安装失败会打印明确的系统安装命令
8. 后台启动或复用全局 Web 控制台，注册当前项目，打印 URL、PID、runtime 文件和日志文件，然后把当前终端还给用户

输出示例：

```text
hello-cc web started in background
pid: 12345
project: /path/to/project
database: /path/to/project/.hello-cc/mesh.db
runtime: /path/to/project/.hello-cc/runtime.json
log: /path/to/project/.hello-cc/web.log
open: http://<machine-ip>:8787/?token=<token>&project=%2Fpath%2Fto%2Fproject
local: http://127.0.0.1:8787/?token=<token>&project=%2Fpath%2Fto%2Fproject
shims: installed claude, codex
PATH updated in ~/.bashrc; open a new terminal or source it
stop: hcc down
```

`hcc web` 使用单个全局 Web runtime。你在另一个项目目录再次运行 `hcc web` 时，不会再开一个端口，而是把那个项目注册到同一个 Web 控制台。前端 Project 下拉框可以在不同项目 root 之间切换；每个项目仍然使用自己的 `.hello-cc/mesh.db`，任务、消息、锁和 peers 不会混在一起。

第一次安装 shim 后，打开新终端，或根据当前 shell 重新加载配置：

- bash: `source ~/.bashrc`
- zsh: `source ~/.zshrc`
- fish: `source ~/.config/fish/config.fish`

之后在这个项目目录中直接输入：

```bash
claude
codex
claude --resume <session-id>
codex resume <session-id>
```

这些命令会被 hello-cc shim 包装为本机 tmux 常驻终端：

- 本地终端会 attach 到同一个 tmux 会话，仍然可以像普通 Claude/Codex 一样交互。
- Web 控制台看到并操作的是同一个 tmux pane，不是浏览器里临时创建的假终端。
- shim 只使用当前项目的 `.hello-cc/runtime.json`。全局 Web runtime 不会让任意
  目录自动进入管理；如果当前项目没有运行过 `hcc web`，`claude` 和 `codex`
  会回退到真实 provider CLI，不会创建 `.hello-cc/mesh.db`。
- `hcc down` 只停止 Web runtime，不会杀掉这些 tmux 会话。
- 重新运行 `hcc web` 后，只要 tmux pane 还活着，Web 会重新接管。

Linux 还可以通过 `/proc` 做更完整的进程自动发现。macOS 上如果需要可靠的终端
控制和稳定 peer 身份，建议使用 shim 启动的会话或 `hcc peer start`。

如果只想初始化本地通信、不启动 Web、不安装 shim，可使用：

```bash
hcc up
```

普通用户优先使用 `hcc web`。
`hcc web --local` 仍然是 Web 模式，只是把 Web runtime 限制为监听
`127.0.0.1`。

## 项目边界

默认项目边界就是当前工作目录。显式运行 `hcc web`、`hcc up`、`hcc task` 或
`hcc peer start` 这类 `hcc` 命令时，如果当前目录没有 `.hello-cc/mesh.db`，
hello-cc 会在首次使用时创建：

```text
/repo-a/.hello-cc/mesh.db
/repo-a/subdir/.hello-cc/mesh.db
```

这两个目录默认是两个不同项目，不会互相看到任务和消息。想让多个终端自然通信，就在同一个项目目录启动它们。

provider shim 更严格：直接运行 `claude` 和 `codex` 时，只有当前项目已经通过
`hcc web` 生成本地 `.hello-cc/runtime.json` 才会加入 hello-cc。它们不会使用
`~/.hello-cc/runtime.json` 去自动注册无关目录，也不会为这些目录创建数据库。

如果确实要让多个路径或 worktree 共用一个总线，需要显式指定：

```bash
hcc --root /path/to/project web
export HCC_ROOT=/path/to/project
export HCC_DB=/path/to/project/.hello-cc/mesh.db
```

hello-cc 不会自动向父目录继承项目边界，这样可以避免子目录会话误加入上层项目。

## 通信模型

hello-cc 的通信不是 CLI 之间点对点互发，也不是必须依赖 MCP。核心是项目本地 SQLite WAL 总线：

```text
Claude/Codex/普通 shell
  -> hooks / hcc 命令 / Web runtime
  -> .hello-cc/mesh.db
  -> peers / tasks / messages / locks / handoffs / events
  -> tmux-backed terminal control
```

任务和消息的读取规则不同：

- 任务是项目事实。所有 peer 默认都能看到未 `done` 且未 `abandoned` 的任务。
- 消息是带收件人的邮箱消息。`hcc msg inbox` 默认读取当前 peer 的未读消息，`hcc msg ack` 记录每个 peer 的已读状态。
- 消息回复有 thread。回复某条消息时使用 `hcc msg reply --id N --body "..."`，
  查看完整线程时使用 `hcc msg thread --id N`。
- `ask` 和 `broadcast` 会写入持久消息；加 `--inject` 时，还会把内容实时注入到 Web runtime 已接管的终端。
- 锁使用 SQLite 事务和 TTL，是协作式冲突避免，不是文件系统强制沙箱。

## Claude/Codex 如何知道其他会话状态

主链路是 hooks 注入，不是依赖 `CLAUDE.md`。

`hcc web` 会安装 Claude Code 和 Codex hooks。在会话启动、用户提交 prompt、工具调用前后、会话空闲等事件中，hooks 会把 hello-cc 当前快照注入给模型，包括：

- 当前 peer 身份
- 活跃 peer 列表
- 未完成任务
- 当前 peer 的未读消息
- 活跃锁
- 来自 `hcc state` 的机器可读下一步动作
- 建议执行的 `hcc status`、`hcc state`、`hcc peers`、`hcc task list`、`hcc msg inbox`、`hcc lock list`

因此，当你在已接入的 Claude/Codex 里问“其他会话在做什么”，模型应该基于 hello-cc 注入的最新状态回答，而不是回答“我无法知道其他会话”。

如果仍然回答不知道，通常是这些原因：

- 没有先在项目目录运行 `hcc web`
- 当前终端还没有加载 `~/.hcc-shims` PATH
- Codex hooks 没有开启，或安装后的 hook 还没有在 Codex 的 hook review 流程里信任
- Claude/Codex 是在不同项目目录启动的
- 当前会话是 `hcc web` 之前打开的 raw 终端，只能靠下一次 hook 事件加入通信，不能被 Web 视觉接管
- 对应 CLI 版本没有触发预期 hook

可以在同一个项目目录用一次性 debug 调用确认 Claude Code 是否真实注入：

```bash
claude -p 'Do you see hello-cc open tasks?' --debug hooks --debug-file /tmp/hcc-claude-hooks.log
```

debug 日志里应该出现 `Hook UserPromptSubmit ... provided additionalContext`，并包含 `hello-cc coordination` 块。

`hcc state --peer <peer> [--resource PATH]` 会读取同一份协作状态，但不会执行
确认消息、认领任务、获取锁、发送消息、创建 handoff 或标记完成这类协作动作。
它返回现有项目数组、统一 `timeline`，以及 `automation` 对象。关键机器字段是
`automation.next_action.argv`：agent 可以显式执行这条 hcc 命令，让协作流程留下
可审计记录，而不是只依赖 prompt 里的自然语言规则。`automation.current_task`
会携带当前 peer 的活动任务，让恢复后的会话继续同一个任务，直到交接、完成或阻塞。

## Web 控制台

默认开启本机和内网访问，并启用 token 认证：

```bash
hcc web
```

裸 `hcc web` 会为本次 runtime 自动生成 token。需要稳定的运维 token 时可显式设置：

```bash
HCC_WEB_TOKEN='choose-a-long-token' hcc web --port 8787
```

同一内网机器打开：

```text
http://<machine-ip>:8787/?token=<token>
```

使用 `hcc web --local` 可只监听 `127.0.0.1`。只有在可信本地/测试环境才使用
`hcc web --no-token`。

Web 控制台能做这些事：

- 在一个端口里切换多个已注册项目 root
- 直接在浏览器里注册新的项目路径
- 查看项目状态：下一步动作、timeline、peers、tasks、locks
- 操作本地终端：启动 Claude/Codex/shell、发送键盘输入、查看输出、停止接管

Web 操作的是 hello-cc 管理的本机 tmux 终端：

- 通过 Web 表单启动的新会话
- 通过 `hcc peer start` 启动的新会话
- 通过 shim 直接输入 `claude` / `codex` 启动的新会话
- 通过 `hcc peer attach` 接入的已有 tmux pane

已经打开的普通 raw 终端不能被无条件捕获或控制，除非它原本就在 tmux、screen 或 hello-cc shim 之下。它仍然可以通过 hooks 和 `hcc` 命令参与任务、消息和锁。
对于这类 coordination-only peer，Web 会通过 Timeline 展示协作轨迹，而不是显示终端流。

## 命令参考

使用 `hcc --help` 查看命令列表，使用 `hcc <command> --help` 查看单个命令。
维护中的命令摘要见 [命令参考](commands.zh-CN.md)。

## 稳定 peer 身份

hello-cc 会尽量让恢复会话复用稳定 peer ID：

| 启动方式 | peer ID |
|---|---|
| `claude --resume abc12345...` | `claude-abc12345` |
| `claude --session-id abc12345...` | `claude-abc12345` |
| `claude --continue` | 先使用终端派生 ID，随后 hooks 记录真实 session 元数据 |
| `claude --fork-session --resume abc12345...` | 先使用终端派生 ID，随后 hooks 记录新 session 元数据 |
| `codex resume abc12345...` | `codex-abc12345` |
| `codex resume --last` | 先使用终端派生 ID，随后 discovery 记录真实 session 元数据 |
| 普通 shell | `shell-<terminal>` |
| 手动 `HCC_PEER=xxx` | 使用 `xxx` |

已知 resume ID 的会话重启后会保持同一个 peer ID。启动前不知道真实 provider session ID 的模式，会先用终端派生 ID，启动后再记录真实 provider session 元数据。

## 典型工作流

创建任务：

```bash
hcc task create --title "重构路由诊断" \
  --body "保持变更范围小。" --priority 20
```

认领并加锁：

```bash
hcc task next
hcc lock acquire --resource vllm/router --ttl 900 --reason "实现路由诊断"
```

`task next` 会先返回当前 peer 已经认领、运行、审查或阻塞中的任务。只有明确
要再接一个 pending 任务时，才使用 `hcc task next --force`。

当工作确实可以并行时，用显式团队把父任务拆成子任务：

```bash
hcc team plan --from-task 12 \
  --item "docs:更新用户指南" \
  --item "tests:增加回归测试" \
  --workers codex:1,claude:1

hcc team start --from-task 12 \
  --item "docs:更新用户指南" \
  --item "tests:增加回归测试" \
  --workers codex:1,claude:1

hcc team status --task 12
```

`team plan` 是只读命令。`team start` 会创建子任务和分配消息，但不会隐藏地启动
模型进程。每个 agent 仍然通过普通任务、锁、交接和完成命令处理自己的子任务。

发消息或实时注入：

```bash
hcc msg send --to claude-a --body "实现已准备好供审查。"
hcc msg reply --id 12 --body "已审查，未发现阻塞问题。"
hcc msg thread --id 12
hcc ask claude-a "请审查当前实现。" --inject
hcc broadcast "暂停编辑 vllm/router，等待任务完成。" --inject
```

完成并交接：

```bash
hcc handoff create --to claude-a \
  --summary "已实现路由诊断变更。" \
  --tests "pytest tests/router" \
  --risks "未跑完整基准"

hcc task done --id 1 --summary "已完成并交接。"
hcc lock release --resource vllm/router
```

## 环境变量

| 变量 | 用途 |
|---|---|
| `HCC_PEER` | 默认 peer 身份 |
| `HCC_ROOT` | 覆盖项目根目录 |
| `HCC_DB` | 覆盖数据库路径 |
| `HCC_WEB_TOKEN` | 设置显式 Web 访问令牌 |
| `HCC_RUNTIME_CA` | `HCC_RUNTIME_URL=https` 端点的 CA 文件 |
| `HCC_RUNTIME_URL` | 直接指定 runtime URL |
| `HCC_NO_AUTO_INSTALL_TMUX=1` | 禁用 tmux 自动安装，主要用于测试 |

`claude` / `codex` shim 和 `hcc peer start` 会使用当前启动终端的环境变量创建 tmux-backed 会话，不使用后台 Web runtime 启动时的旧环境。这样你可以在新终端里先 `export ANTHROPIC_*`、`CLAUDE_CODE_*` 或其他 provider 变量，再运行 `claude` / `codex`。

已经运行的 CLI 进程不能被操作系统原地修改环境变量。`claude` / `codex` shim 会用 `--restart-env` 调用 `hcc peer start`，因此 hello-cc 会为同一个 resume/session peer 记录启动环境指纹。当你从新终端再次启动它且环境已变化时，如果对应 tmux 会话没有本地 tmux client 或 Web client 正在连接，hello-cc 会自动重启这个 tmux 会话并应用新环境。如果会话正在被操作，会提示先 detach/关闭 Web 连接，或运行 `hcc peer stop <peer>` 后再启动。

如果直接调用 `hcc peer start`，需要加 `--restart-env` 才会启用同样的环境变化自动重启行为。

shim 只接管交互式终端会话。元命令和维护命令会直通真实 provider CLI，例如 `claude --help`、`claude --version`、`claude --print`、`claude --bare`、`claude --safe-mode`、`codex --help`、`codex --version`，以及 `codex exec`、`codex review`、`codex doctor`、`codex mcp` 等非交互 Codex 子命令。交互式的 `claude`、`claude --resume ...`、`codex`、`codex resume ...`、`codex fork ...` 会走 tmux-backed，会出现在 Web 控制台里。
