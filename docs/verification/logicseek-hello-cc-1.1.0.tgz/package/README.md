# hello-cc

<p align="center">
  <img src="assets/logo.svg" width="160" alt="hello-cc logo">
</p>

<p align="center">
  <a href="https://github.com/Dullne/hello-cc"><img src="https://img.shields.io/github/stars/Dullne/hello-cc?style=flat-square&color=40c4aa" alt="GitHub stars"></a>
  <a href="https://www.npmjs.com/package/@logicseek/hello-cc"><img src="https://img.shields.io/npm/v/@logicseek/hello-cc?style=flat-square&color=40c4aa" alt="npm version"></a>
  <a href="https://nodejs.org"><img src="https://img.shields.io/badge/node-%3E%3D24.0.0-brightgreen?style=flat-square" alt="node >=24"></a>
  <a href="./LICENSE"><img src="https://img.shields.io/badge/license-Apache%202.0-blue?style=flat-square" alt="license Apache 2.0"></a>
</p>

<p align="center"><b>English</b> | <a href="README.zh-CN.md">中文</a></p>

`hello-cc` is a local control plane for Claude Code, Codex, and other coding
CLI sessions. It gives every terminal in one project a shared task board,
mailbox, lock table, and browser console while keeping the real local terminal
as the source of interaction.

<p align="center">
  <img src="assets/screenshots/web-console.png" width="900" alt="hello-cc Web console showing agent sessions, task state, locks, messages, and terminal output">
</p>

<p align="center">
  <em>One local Web console for tmux-backed Claude Code, Codex, tasks, locks, messages, and handoffs.</em>
</p>

It is built for developers who run multiple AI coding agents in the same repo
and need them to coordinate instead of guessing what the other sessions are
doing.

## v1 Compatibility And Trust Model

Version 1.0.0 upgrades project databases to schema v7 after creating a verified
pre-migration backup; downgrading that database is unsupported. Provider peer
IDs now hash the full provider session value and old IDs are not remapped.
Runtime API v2 and per-connection terminal action tokens are required.

Liveness follows tmux/non-tmux process evidence: sleep or detachment does not
kill a live session, and only unknown evidence receives the bounded 120-second
grace. `hcc gc` retains history unless `--history` is explicit. `--tls` encrypts
the console; `--trust-proxy` requires a fixed `--proxy-origin`. Two risks remain
intentional: the default listener is plaintext HTTP on `0.0.0.0` for trusted
LANs, and an authenticated browser may select any existing server directory.

## Highlights

- **Shared project memory**: peers, tasks, messages, locks, handoffs, and
  events are stored in `<project>/.hello-cc/mesh.db`.
- **Real terminal control**: Web attaches to the same local tmux pane as your
  terminal, not a separate browser-only shell.
- **Claude/Codex awareness**: hooks inject live `hcc` state before model turns,
  so agents can answer from current project state.
- **Conflict avoidance**: advisory locks and handoffs make multi-agent editing
  explicit.
- **Explicit team splits**: `hcc team plan/start/status` turns one parallel
  task into auditable child tasks without hidden auto-spawning.
- **Resume-friendly identity**: resumed Claude/Codex sessions map back to
  stable peers when provider session ids are available.
- **One console, many projects**: one local Web runtime can switch between
  registered project roots.

## Install And Manage

hello-cc supports Linux and macOS. Node.js 24 or newer is required, and
browser-controllable terminals require `tmux`. Native Windows shells are not
currently supported; use WSL for a Linux-like environment.

Linux has richer process auto-discovery through `/proc`. On macOS, use
hello-cc shims or `hcc peer start` for reliable tmux-managed terminal sessions.

Install Node.js 24 or newer from the official Node.js packages or a Node
version manager. Then install `tmux` for your platform:

```bash
# Debian / Ubuntu
sudo apt-get update && sudo apt-get install -y tmux
# Fedora / RHEL
sudo dnf install -y tmux
# Older RHEL / CentOS
sudo yum install -y tmux
# Alpine
sudo apk add tmux
# Arch Linux
sudo pacman -S --needed tmux
# openSUSE
sudo zypper install tmux
# macOS only
brew install tmux
```

On Linux, use the distribution package manager; Homebrew is only the macOS
command above. Root shells can omit `sudo`. In WSL, run the matching Linux
distribution commands inside WSL. Then install and verify hello-cc:

```bash
npm install -g @logicseek/hello-cc
node --version
npm --version
tmux -V
hcc --version
hcc --help
```

If npm reports `EACCES`, use a Node version manager or a user-owned npm prefix;
do not work around it with `sudo npm install -g`.

Update an existing global install:

```bash
hcc update
```

Or run it without a global install:

```bash
npx @logicseek/hello-cc web
```

Remove hooks, shims, and the shell PATH entry from this machine:

```bash
hcc uninstall
```

Remove the global npm package:

```bash
npm uninstall -g @logicseek/hello-cc
```

## Quick Start

Run this inside the project you want agents to share:

```bash
cd /path/to/project
hcc web
```

Then open the printed URL. By default, `hcc web` listens on LAN interfaces and
requests `0.0.0.0:8787`, using a token generated for that runtime. If
port 8787 is already busy and you did not pass `--port`, it automatically tries
the next available port. The command prints both the LAN login URL and the local
loopback URL:

```text
open: http://<machine-ip>:8787/?token=<runtime-token>&project=/path/to/project
local: http://127.0.0.1:8787/?token=<runtime-token>&project=/path/to/project
```

Use `--local` to bind only to `127.0.0.1`, or `--port N` to request a specific
port. `hcc web` initializes the project bus, installs Claude/Codex hooks and
shims, starts or reuses the Web console, and returns the terminal to you.
`hcc web --local` is still Web mode; it only limits the listener to loopback.
Use `hcc up` when you want local coordination commands without the Web console
or shims.

After the first shim install, open a new terminal or reload the rc file for
your shell:

- bash: `source ~/.bashrc`
- zsh: `source ~/.zshrc`
- fish: `source ~/.config/fish/config.fish`

Start normal agent sessions from the project:

```bash
claude
codex
claude --resume <session-id>
codex resume <session-id>
```

Those sessions become tmux-backed peers that can be seen and controlled from
Web while remaining usable from the local terminal. The shims only use the
current project's runtime file. If you start `claude` or `codex` in a directory
where `hcc web` has not created `.hello-cc/runtime.json`, the shim falls back to
the real provider CLI instead of using the global Web runtime or creating a new
project database.

## Basic Workflow

```bash
hcc task create --title "Review router changes" --priority 20
hcc task next
hcc task running --id 1 --summary "Started"
hcc lock acquire --resource src/router --ttl 900 --reason "edit router"
hcc status
hcc handoff create --summary "Router change ready for review" --tests "npm test"
hcc task done --id 1 --summary "Done"
```

Ask an agent what is happening in the project:

```text
What are the other hello-cc sessions doing?
```

Attached Claude/Codex sessions should answer from live `hcc` state rather than
generic session-isolation assumptions.

## Documentation

- [Documentation Index](docs/README.md): all user and implementation docs.
- [User Guide](docs/guide.md): setup, Web console, workflows, coordination
  semantics, and environment behavior.
- [Command Reference](docs/commands.md): compact public command list.
- [Project directory identity and private state](docs/private-state.md): v2
  bindings, replacement generations, offline upgrades and verified Codex history.
- [DeepSeek Harness](docs/dsh.md): hooks/Cordis collaboration, ACP workers,
  project setup and Web launch, with real-model and local-package acceptance evidence.
- [Native Workers](docs/native.md): HCC-owned Codex, Claude SDK, and dsh ACP
  workers, delivery receipts, permissions, and saved-session ownership.
- [Changelog](CHANGELOG.md): release notes for published versions.
- [Design Notes](docs/design.md): product boundaries and coordination model.
- [Implementation Notes](docs/implementation.md): architecture and internal
  protocol.

## Testing

```bash
npm test
```

The regression suite uses temporary projects, fake Claude/Codex binaries,
temporary tmux sessions, and a temporary Web runtime to test the main flows.

## License

[Apache-2.0](LICENSE)

---

<p align="center">
  <a href="https://star-history.com/#Dullne/hello-cc&Date">
    <img src="https://api.star-history.com/svg?repos=Dullne/hello-cc&type=Date" width="600" alt="Star History Chart">
  </a>
</p>
