# Native workers

Native mode runs background workers that HCC creates and owns. HCC keeps the
shared peer, task, message, lock, and handoff model; each provider adapter owns
its execution connection and reports structured lifecycle events.

| Provider | Connection | Session identity | Busy-worker input |
| --- | --- | --- | --- |
| Codex | Owned `codex app-server` over stdio JSON-RPC | Codex thread ID | Adapter supports `turn/steer` with the active turn precondition |
| Claude | Optional Claude Agent SDK, persistent streaming input | Claude session ID confirmed by SDK initialization | One submission at a time; steering is unsupported |
| DeepSeek Harness | Owned `dsh --profile acp` process | ACP session ID | One submission at a time; steering is unsupported |

The HCC host currently dispatches one inbox message at a time to each worker,
including for Codex. Adapter support for steering does not mean the host sends
multiple pending inbox messages into the same turn. ACP resume and session close
depend on the extensions the provider advertises. HCC does not claim that an ACP
resume replays the original conversation transcript.

## Requirements

Use Node.js 24 or later and a provider installed and authenticated in the same
environment as HCC. Native mode preserves authentication configuration and does
not rewrite accounts, provider settings, or the user's home directory.

Codex needs an app-server-compatible CLI. DeepSeek Harness uses its ACP profile;
the implementation targets `@deepseek-ai/dsh-acp@0.2.0-rc.2`. This mode does not
connect to a running dsh Web service.

Claude's SDK remains optional and is loaded only when a Claude worker opens.
For a checkout of this repository, install the documented SDK version explicitly:

```sh
npm install --no-save --package-lock=false @anthropic-ai/claude-agent-sdk@0.3.287
```

For a global HCC installation, install that version into the same npm prefix:

```sh
npm install -g @anthropic-ai/claude-agent-sdk@0.3.287
```

Alternatively, install the optional SDK in the worker's project:

```sh
cd /absolute/path/to/worker-project
npm install --no-save --package-lock=false @anthropic-ai/claude-agent-sdk@0.3.287
```

The default loader first checks HCC's installation, then the worker project's
node_modules, so a global HCC can use a project-local SDK. HCC never installs
packages automatically. Missing SDKs produce installation guidance; errors from
a found SDK's exports or dependencies retain their original cause. A separate
real Web approval receipt (source checkout: `docs/verification/2026-10-02-native-web-claude-default-sdk.json`)
exercises this default project lookup without injecting a query function. It
does not verify a published package or an employee installation.

## CLI

Run commands from the project you want the workers to share, or select it with
the existing global `--root` and `--db` options.

```sh
hcc native up
hcc native start --peer codex-reviewer --provider codex
hcc native start --peer claude-reviewer --provider claude
hcc native start --peer dsh-reviewer --provider dsh
hcc native send --peer codex-reviewer --from coordinator --body "Review the current changes and report concrete findings."
hcc native status
hcc native deliveries --peer codex-reviewer
hcc native events --peer codex-reviewer --after 0
hcc native requests --peer codex-reviewer
hcc native respond --peer codex-reviewer --request REQUEST_ID --decision accept
hcc msg inbox --peer coordinator
```

`start` starts the project's native runtime when needed. Workers share its HCC
message bus even when `--cwd DIR` selects another working directory. `--model
MODEL` selects a provider-supported model. `--binary PATH` overrides the Codex
or dsh executable. Claude uses the SDK and rejects `--binary`.

| Command | Options / behavior |
| --- | --- |
| `hcc native up` | Start or reuse the project's background runtime |
| `hcc native status` | Inspect persisted worker state and runtime identity |
| `hcc native start` | Required `--peer NAME --provider codex\|claude\|dsh`; optional `--cwd DIR --model MODEL --resume last`; `--binary PATH` is available only for Codex and dsh |
| `hcc native send` | Required `--peer NAME --body TEXT`; optional `--from NAME --task ID`; returns a durable message/submission receipt |
| `hcc native deliveries` | Optional `--peer NAME`; inspect delivery receipts |
| `hcc native events` | Required `--peer NAME`; optional `--after ID`; inspect a bounded event history |
| `hcc native requests` | Requires `--peer NAME`; inspect pending requests bound to this executor, session and turn |
| `hcc native respond` | Requires `--peer NAME --request ID --decision accept\|decline\|cancel`; use `--response-file JSON` for permission subsets or answers |
| `hcc native interrupt` | Required `--peer NAME`; optional `--turn ID`; request interruption of the active turn |
| `hcc native close` | Required `--peer NAME`; close that worker's owned connection/process |
| `hcc native down` | Request worker closure and runtime shutdown; returns a stop-request receipt |

The `native down` receipt confirms the stop request, not completed shutdown.
Inspect `native status` to check the outcome. If provider shutdown fails, HCC
retains runtime ownership and reports the error in `status.shutdown_error`;
resolve the reported problem and retry `native down`.

Worker events retain semantic output and completion evidence; token deltas are
not persisted as delivery receipts. The runtime keeps local state under
`<project>/.hello-cc/native/` and coordination records in the selected HCC
database. Runtime control is a local authenticated API, separate from the
browser terminal transport. Treat its local runtime pointer and log as private
project state.

## Reading delivery receipts

A successful `native send` queues a message. It does not mean the provider has
read it, completed it, or returned a business result.

| State | Meaning |
| --- | --- |
| `queued` | Stored on HCC's message bus, waiting for dispatch |
| `dispatching` | HCC started handing the submission to its adapter; provider admission is still pending |
| `submitted` | The adapter queued/wrote the prompt, without a provider admission receipt |
| `accepted` | Provider-confirmed admission or matching provider output establishes that this submission/turn is being processed; work is still pending |
| `completed` | An authoritative matching main-turn result reports success; HCC acknowledges the message and can write an automatic reply for a non-reply message |
| `failed` | A definitive rejection or unsuccessful main-turn result; not a successful acknowledgement |
| `uncertain` | A timeout, lost process/connection, or runtime restart left the outcome unknown; automatic retry could duplicate work |

An SDK consuming an input iterator proves transport submission, not provider
acceptance or a completed model turn. Claude advances from `submitted` to
`accepted` after matching assistant output is observed. Claude reports its
actual session ID on initialization, so a freshly
opened worker can legitimately have a null session ID until its first prompt.
An interrupt request does not cancel an SDK input that is still queued and does
not itself complete a delivery. Only a matching main-turn result settles it.

An inbox message with `kind: 'reply'` is still delivered as context and
acknowledged after its main turn succeeds. Its output remains in `events`, but
HCC does not automatically generate another reply, preventing reply loops.
For other message kinds, a successful main turn with output writes an automatic
reply to the sender.

For an uncertain delivery, inspect `deliveries`, `events`, and provider state
before sending a replacement. HCC leaves uncertain deliveries out of automatic
retries. Runtime restart records in-flight work as uncertain rather than
pretending it failed or completed.

## Ownership, hooks, and permissions

Resume an HCC-owned saved session with the same peer and provider:

```sh
hcc native close --peer codex-reviewer
hcc native start --peer codex-reviewer --provider codex --resume last
```

An explicit saved ID is accepted only when it matches HCC's record for that peer
and provider. Resume restores a conversation through a newly owned connection;
it does not attach to an existing live TUI or desktop instance. HCC cannot prove
that an external application has independently opened the same saved session,
so do not open the same conversation concurrently outside the owned runtime.

Native workers receive a worker-specific `HCC_ROOT`, `HCC_DB`, `HCC_PEER`, and
`HCC_NATIVE_OWNER`. A provider hook must match the peer's native transport owner.
Its native hook path only heartbeats that owner and renews its locks. It does
not change provider bindings or process identity, inject another copy of the
inbox, acknowledge messages, or block a Stop hook. Mismatched owner markers fail
without falling back to normal terminal-hook delivery.

Providers keep their permission checks. HCC-hosted workers wait for an explicit
response from the current Web controller or the local CLI when an operation
requires approval. Closing Web leaves both the worker and its pending requests
available to the local CLI. Requests expire when their turn ends, interruption
is accepted, the provider resolves them, or the worker closes. A late request
from an interrupted turn cannot reopen approval. Direct adapters without a
hosted responder retain conservative denial.

| Provider | Hosted interaction |
| --- | --- |
| Codex | Command/file approval, requested filesystem/network permission subsets with explicit turn/session duration, questions including freeform/secret input, and one-call empty-form MCP tool approvals |
| Claude | SDK tool permission callback; approval grants the original tool input once without rewriting it |
| dsh ACP | Offered permission choices; approval selects only `allow_once`, never `allow_always` |

rc.2 may send only a tool-call ID in an ACP approval request. The adapter correlates same-session/turn tool updates to show the operation input. Missing or truncated input still allows rejection; acceptance returns `NATIVE_APPROVAL_CONTEXT_MISSING`. See dsh installed acceptance (source checkout: `docs/verification/2026-10-02-dsh-cordis-native.md`).

Hosted interactive Codex threads explicitly enable
`features.default_mode_request_user_input` and `features.request_permissions_tool`
in their private start/resume configuration. Web-owned start/resume/fork uses
the same switches. These experimental capabilities were exercised in Codex
0.144.6; they do not write global configuration or grant filesystem/network
permissions. Approval remains on-request with the user as reviewer.
Noninteractive direct adapters retain their defaults. The permission form
shows mirrored legacy and current path entries once, preserving distinct
access choices, original request indices and denial rules.

Claude keeps `permissionMode: 'default'`; tools already permitted by that mode
can run. Approval responses are fenced by the runtime generation, worker owner,
provider, session, turn and request ID. Web observers cannot submit responses;
a browser that loses control cannot answer with its old control epoch. Direct
answers, including secrets, are omitted from HCC snapshots, events, delivery
receipts and browser storage; form drafts remain in browser memory only.

For Codex permissions/questions, use a response file. These are separate
examples; paths, question IDs and answer labels must match the pending request:

```json
{"permissions":{"fileSystem":{"read":["/requested/read/path"]}},"scope":"turn"}
```

```json
{"answers":{"question-id":{"answers":["An offered label or permitted freeform answer"]}}}
```

```sh
hcc native respond --peer codex-reviewer --request REQUEST_ID --decision accept --response-file ./response.json
hcc native respond --peer codex-reviewer --request REQUEST_ID --decision cancel
```

Only `permissions`, `scope` and `answers` are accepted in that file. Permissions
can narrow the request but cannot add paths or network access; requested deny
entries must be retained when granting filesystem access. Answer every question
explicitly. Truncated requests can only be declined or cancelled. Arbitrary MCP
forms, URL authentication, dynamic tools and account-token refresh requests are
outside this responder's supported interaction set.

## Current boundaries

- Existing Codex/Claude/dsh terminal sessions remain on their original transport;
  attaching to or taking over an existing TUI/Desktop session is not implemented.
- Web discovers existing native workers in the same project and exposes messages,
  delivery receipts, interruption, and explicit closure. Closing the page or Web
  runtime preserves the independent native worker. Human responses are bound to
  the current executor and turn. See the [Web handoff guide](web-handoff.zh-CN.md).
- Codex, Claude and dsh native workers receive project- and peer-scoped HCC MCP
  configuration. Writes still require provider permission and HCC ownership checks.
- Provider-internal `SendMessage`, subagent/team discovery, and Codex delegation
  tools are not exposed as one cross-vendor protocol. HCC routes cross-provider
  messages through its own durable bus and adapters.
- Task claiming, file locks, handoffs, and completion checks remain explicit HCC
  coordination operations; successful prompt execution alone does not prove a
  task's business acceptance.
- Adapter tests cover protocol and interaction boundaries. The authenticated
  checks below provide separate evidence for model execution and scoped MCP;
  packaged-client installation and business acceptance remain unverified.


## Authenticated acceptance on October 2, 2026

Independent temporary projects and provider state directories were used for real
model calls with Codex 0.144.6, Claude Agent SDK 0.3.287 and DSH 0.2.0-rc.2. The
session lifecycle receipt (source checkout: `docs/verification/2026-10-02-native-live-lifecycle.json`)
covers correlated replies and ACKs, idempotent queueing, continuing context,
owned close/resume and active interruption. A real Codex command approval was
declined, and its test write outside the allowed sandbox did not occur.

The cross-provider receipt (source checkout: `docs/verification/2026-10-02-native-live-communication.json`)
covers actual model calls to the scoped HCC MCP message tool along
`Codex → Claude → dsh → Codex`, receiver model replies, reply consumption and ACK,
and the absence of automatic reply loops. It also verifies discovery and sending
through the Web bridge, original provider binding preservation and worker
survival after closing that bridge. These receipts are separate source snapshots.

Codex MCP tool approvals use `mcpServer/elicitation/request`. HCC submits the
official action/content response for explicit tool confirmations without
persisting session/always authorization. Approving arbitrary form fields or URL
authentication is unsupported; decline and cancel remain available.

The local validation receipt (source checkout: `docs/verification/2026-10-02-native-live-validation.json`)
records the unit suite (785 passed, one platform-dependent skip), a 63-module
static audit, the 13-stage regression and offline harness failure cleanup.
Each check retains its own execution time and evidence digest.

The opt-in `scripts/native-live-acceptance.mjs` harness defaults to help. It calls
models and consumes the caller's provider quota only with `--run-live`:

```sh
node scripts/native-live-acceptance.mjs --run-live --provider all \
  --codex-bin /absolute/path/to/codex \
  --dsh-bin /absolute/path/to/dsh \
  --claude-sdk /absolute/path/to/claude-agent-sdk/sdk.mjs \
  --permission-probe --cross-provider \
  --output /absolute/path/to/receipt.json
```

Use `--communication-only` for the cross-provider test alone. The explicit SDK
entry was used for Claude acceptance; this does not prove repository-default SDK
resolution or package installation. The script installs no dependencies, never
attaches to existing conversations, and closes owned test processes and removes
credential copies on exit. Web evidence covers its service/bridge control layer,
not a full browser interaction or published-client acceptance. Real business task
acceptance remains a separate check.


For real model and browser interactions, use
`scripts/web-native-interaction-acceptance.mjs`. It defaults to help; only
`--run-live --provider codex|claude|all` invokes models. Set
`HCC_ACCEPTANCE_PLAYWRIGHT` and optionally `HCC_ACCEPTANCE_CHROME`.
`--claude-package DIR` links an installed SDK package into the isolated worker
project for default resolution, without injecting its query function. The
harness checks explicit approval and rejection and continuing the original
session. It uses existing authentication/quota, cleans test provider homes and
processes, and never attaches to existing user conversations.
